To compile this example copy the files in the include directory into this directory.
To run this example copy the libxl.dll file from the bin folder into this directory after compiling.